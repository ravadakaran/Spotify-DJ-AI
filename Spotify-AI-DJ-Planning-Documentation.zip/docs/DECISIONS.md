# Architecture decisions

Status: recommended planning baseline, 18 October 2026. No runtime choices have been benchmarked and no application has been built. Source requirements outrank these recommendations. Record future changes with date, owner, affected REQ IDs and migration/test consequences.

| ADR | Decision | Alternatives and rationale | Status / trade-off |
| --- | --- | --- | --- |
| ADR-001 | Track A, Option B: MERN JavaScript | Python/FastAPI/PostgreSQL is attractive for scientific tooling and allowed as Option C; Java/Spring is also allowed. Node suits shared realtime/event logic and avoids a second language for this small build | Provisional pending OQ-01; cannot mix PostgreSQL/TypeScript into Option B without changing PRD scope |
| ADR-002 | React + Vite + Tailwind, JavaScript modules/JSDoc | TypeScript offers stronger compile-time contracts but explicitly conflicts with Option B. Next.js SSR adds little to private console; plain CSS is viable | Recommended; runtime schema validation and tests carry contract safety |
| ADR-003 | Express + Socket.IO, one process | Fastify possible technically but not the chosen PRD row. Native WS would require more reconnect/room plumbing; microservices add operational burden | Recommended; Socket.IO does not supply durable exactly-once delivery |
| ADR-004 | MongoDB + Mongoose, local replica set | PostgreSQL has stronger FK/relational constraints but belongs to another PRD option. Embedded timeline fits read path | Recommended; explicit service integrity checks and transaction setup required |
| ADR-005 | In-memory per-room serialized authority and batched history | Synchronous per-vote DB transactions conflict with §9.4 and latency intent. Redis/distributed coordination unnecessary on one instance | Explicit PRD direction; loss window requires OQ-04 agreement |
| ADR-006 | Local legal catalog, manual feature ingestion | Real Spotify excluded; automatic extraction optional and not needed to demonstrate valid matching | Source-mandated exclusion; preserves offline reproducibility |
| ADR-007 | Deterministic matching, local sentiment, lexical RAG + local model | LLM deciding order is nondeterministic; embeddings unnecessary at initial scale; remote model adds privacy/cost dependencies | Model artifact remains undecided until hardware/license/latency checks |
| ADR-008 | Room-scoped Listener/Co-DJ/Host, separate global Admin | PRD reference users.role alone would incorrectly grant Host authority across all rooms | Provisional clarification; all four roles still enforced |
| ADR-009 | Freeze on detected Host loss; ties await authorized choice | Automatic succession possible but requires successor ordering and consent rules absent from source | Provisional OQ-05; deterministic and testable, temporarily stalls playback |
| ADR-010 | Hard compatibility overrides crowd/manual immediate-next choices | Blind winner splice could violate 100% segue rule | Provisional OQ-06; incompatible winners deferred with explanation |
| ADR-011 | 15-minute JWT + rotating refresh cookie | LocalStorage bearer tokens increase exposure; long-lived JWT fails source limit | Recommended; CSRF/origin protections and revocation handling needed |
| ADR-012 | Worker-thread hybrid fitting and atomic artifact swap | Full model service/vector DB unjustified; content-only fallback does not replace hybrid requirement | Recommended; larger held-out dataset necessary |
| ADR-013 | Explicit Host approval before segue commit | Auto mode could better automate DJ but approval semantics are unspecified | Provisional OQ-08; rejected/timed-out proposal pauses rather than auto-plays |
| ADR-014 | Preserve four-week source constraint as relative checkpoints | New dates/guaranteed estimates would be invented | OQ-02 unresolved; schedule relevance must be confirmed |

## Deferred decisions and change criteria

OQ-03 selects exact Node/package versions, model/license/runtime and hardware. Pin supported compatible releases and lockfiles during implementation; this plan makes no “latest version” claims. OQ-04 resolves data loss/recovery requirements. OQ-07 sets sentiment language/window, recency depth and outro timing. OQ-09 sets privacy retention and deletion. OQ-10 confirms that local scheduling is sufficient for playback expectations.

Add Redis/distributed room ownership only when a measured single-instance limitation requires it. Add embeddings only if lexical retrieval demonstrably misses authored facts. Add automatic audio analysis only for authorized local files and when manual profiles become a proven bottleneck. Revisit database/stack only through an explicit source deviation, not incidental implementation convenience. Real Spotify integration is a separate scope/policy assessment, not a future checkbox automatically inherited from this plan.

No provisional choice is a claim of user approval. Phase 0 makes critical choices concrete; other defaults should remain visible in configuration, docs and tests until confirmed.
