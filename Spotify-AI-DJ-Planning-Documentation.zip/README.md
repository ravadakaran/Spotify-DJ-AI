# Spotify AI DJ Engine

Planning package for **AI DJ Studio: Collaborative Live Queue Curation & Sentiment-Aware Audio Engine**. This is a private prototype based on the supplied PRD, not a Spotify integration or an assertion of Spotify affiliation.

**Status: documentation only. No application, migrations, tests, seed assets, or deployment have been implemented or executed.** Commands below and in the setup guide describe the future implementation contract.

## Scope and stack

Recommended delivery: PRD Track A (full stack), Option B: React, JavaScript, Vite, Tailwind CSS, Node.js, Express, Socket.IO, MongoDB and Mongoose; Jest/Supertest and Playwright for verification. Plain JavaScript is intentional: PRD §8 requires it for this option. PostgreSQL and TypeScript are evaluated in [decisions](docs/DECISIONS.md), but are not part of the selected plan.

Build private lounges with an authoritative live queue, votes and Soundclash battles; local audio playback; BPM/Camelot matching; chat sentiment; grounded text banter and Q&A; hybrid recommendations; session analytics; and four-role access control. Use original or appropriately licensed local audio and authored metadata. Real Spotify accounts/catalog/API access, waveform mixing, synthesized speech/music and public streaming are excluded by PRD §4.2.

## Read and develop in this order

| File | Purpose |
| --- | --- |
| [PROJECT_REQUIREMENTS](docs/PROJECT_REQUIREMENTS.md) | Source analysis, requirement IDs, contradictions, scope and questions |
| [DECISIONS](docs/DECISIONS.md) | Stack rationale and provisional behavior choices |
| [IMPLEMENTATION_PLAN](docs/IMPLEMENTATION_PLAN.md) | Ordered phases and completion gates |
| [ARCHITECTURE](docs/ARCHITECTURE.md) | Components, diagrams and recovery model |
| [DATABASE_SCHEMA](docs/DATABASE_SCHEMA.md) | Collections, relational comparison, constraints and migration plan |
| [API_SPECIFICATION](docs/API_SPECIFICATION.md) | REST, authentication, payloads and socket contracts |
| [AI_MUSIC_ENGINE](docs/AI_MUSIC_ENGINE.md) | Exact matching, sentiment, retrieval and recommendation design |
| [TESTING_STRATEGY](docs/TESTING_STRATEGY.md) | Requirement-linked checks and honest performance evidence |
| [SECURITY](docs/SECURITY.md) | Roles, tokens, validation, privacy and operational controls |
| [ENVIRONMENT_SETUP](docs/ENVIRONMENT_SETUP.md) | Planned prerequisites, variables, commands and deployment runbook |
| [TASKS](docs/TASKS.md) | Ordered, unchecked implementation backlog |
| [PHASE_TODO_LIST](docs/PHASE_TODO_LIST.md) | Granular phase-by-phase implementation checklists and DoD gates |
| [EXTERNAL_CAPABILITIES](docs/EXTERNAL_CAPABILITIES.md) | Dated official-source verification and integration exclusions |
| [CONTRIBUTING](CONTRIBUTING.md) | Development and review workflow |
| [AGENTS](AGENTS.md) | Persistent implementation constraints |

Primary source: [Project Document.docx](Document/Project%20Document.docx), v1.0, September 2026. Its institutional branding is source text, not independently verified provenance. The ZIP packages generated documentation; retain the original source beside it when implementing.

## Setup, test and deployment preview

Prerequisites: Git, a supported Node LTS release pinned during Phase 1, npm, Docker/Compose for a local MongoDB replica set, three legal local audio assets and their profiles, and a local LLM runtime/model selected and benchmarked in Phase 0. An API key is needed only if a hosted LLM is deliberately selected. No Spotify credentials are required.

After the scripts and Compose services are created, the intended sequence is `npm ci`, configure an ignored `.env`, `docker compose up -d mongo`, `npm run db:migrate`, `npm run db:seed`, and `npm run dev`. Run `npm test`, `npm run test:integration`, `npm run test:e2e`, `npm run test:load` and `npm run eval:ai` once those scripts exist. These commands do not run against this documentation-only repository today.

Deploy one application instance behind TLS with persistent MongoDB and asset volumes on a private host. Run migrations, readiness checks, a two-session smoke test and backup/restore verification before accepting the deployment. Do not horizontally replicate the in-memory room authority. See [setup](docs/ENVIRONMENT_SETUP.md) for the full procedure and rollback.

## First step

Complete **Phase 0: scope, data and feasibility gate**, then start **Phase 1: foundation and one vertical slice**. Confirm Track A/Option B, identify legal demo assets and hardware, resolve critical queue semantics, and select an LLM that can be evaluated. The PRD's four-week schedule is a source constraint, not a new delivery promise; dates and effort commitments remain unset.
